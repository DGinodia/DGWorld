## 2.0.2
* UPD: powerbi-visuals-tools has been updated to 3.0.9 to add IE11 support
* UPD: API has been updated to 2.3.0 to add IE11 support
* UPD: powerbi-visuals-api has been updated to 2.3.1 to add IE11 support
* @babel/polyfill has been used as powerbi-visuals-tools@3.0.9 requirement

## 2.0.1
* Updared dependencies
* Azure Pipelines integration

## 2.0.0
* API 2.1.0
* Webpack integration

## 1.9.0
* High contrast mode
* API 1.13.0

## 1.8.1
* Fix displaying of numbers in tooltip

## 1.8.0
* Added restriction for animation and dragging because of performance issue (limit is 200 nodes)

## 1.7.0
* Added localization for all supported languages

## 1.6.1
* UPD: the nodes rendering algorithm (alpha) was changed to optimal algorithm (theta) 

## 1.6.0
* Added support for edges with same source and target

## 1.5.0
* Added drill-down support

## 1.4.0
* Updated dependencies
* Updated API version

## 1.3.8
* New property "Intersection" in "Data labels" option of "Format" panel to hide overlaped labels in visual.
* New option "Bound by box" in "Format" panel to configure the behavior of nodes near a border of visual.